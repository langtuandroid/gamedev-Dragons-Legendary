public class AttackMonsterData
{
	public Monster monster;

	public int damage;
}
