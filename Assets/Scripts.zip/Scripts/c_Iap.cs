public class c_Iap
{
	public string Payload;
}
