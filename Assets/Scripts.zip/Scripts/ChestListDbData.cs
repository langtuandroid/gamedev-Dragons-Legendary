public class ChestListDbData
{
	public int probIdx;

	public int chestHunter;

	public int hunterTier;

	public int hunterLevel;

	public int chestItem;

	public int chestItemN;
}
