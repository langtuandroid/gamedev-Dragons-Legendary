public enum ChestType
{
	Free = 1,
	Worn = 2,
	Mysterious = 3,
	Reward = 4,
	QuickLoot = 5,
	CoinChest = 8
}
