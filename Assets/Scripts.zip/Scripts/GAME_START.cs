public class GAME_START
{
	public string success;

	public int errorCode;

	public GAME_START_RESULT result;

	public CHECK_VERSION_RESULT[] force_update;
}
