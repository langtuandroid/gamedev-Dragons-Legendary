public enum BlockExceptionType
{
	None,
	Obstruction,
	DefaultFix,
	SpecialFix
}
