public class ARENA_STORE_INFO
{
	public int arenaNo;

	public int productIdx;

	public int productType;

	public string itemName;

	public int chestHunter;

	public int hunterTier;

	public int hunterLevel;

	public int itemIdx;

	public int itemN;

	public int costArenaPoint;

	public string soldOutYn;
}
