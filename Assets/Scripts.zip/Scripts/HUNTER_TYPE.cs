public enum HUNTER_TYPE
{
	BLUE,
	GREEN,
	PURPLE,
	RED,
	YELLOW,
	HEAL
}
