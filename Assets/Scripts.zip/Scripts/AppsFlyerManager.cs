using UnityEngine;

public class AppsFlyerManager : MonoBehaviour
{
	private void Start()
	{
		AppsFlyer.setAppsFlyerKey("rpPWfG9Nbc8v2Rk7fYm783");
		AppsFlyer.setAppID("com.cookapps.matchhero");
		AppsFlyer.init("rpPWfG9Nbc8v2Rk7fYm783", "AppsFlyerTrackerCallbacks");
		Application.RequestAdvertisingIdentifierAsync(delegate(string advertisingId, bool trackingEnabled, string error)
		{
			MWLog.Log("advertisingId " + advertisingId + " " + trackingEnabled + " " + error);
			GameInfo.AD_ID = advertisingId;
		});
	}
}
