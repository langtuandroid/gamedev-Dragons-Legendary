public enum InGameTouchState
{
	TouchBegin,
	TouchMove,
	RouchEnd
}
