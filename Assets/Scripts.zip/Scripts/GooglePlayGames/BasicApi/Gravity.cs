namespace GooglePlayGames.BasicApi
{
	public enum Gravity
	{
		TOP = 48,
		BOTTOM = 80,
		LEFT = 3,
		RIGHT = 5,
		CENTER_HORIZONTAL = 1
	}
}
