namespace GooglePlayGames.BasicApi
{
	public enum DataSource
	{
		ReadCacheOrNetwork,
		ReadNetworkOnly
	}
}
