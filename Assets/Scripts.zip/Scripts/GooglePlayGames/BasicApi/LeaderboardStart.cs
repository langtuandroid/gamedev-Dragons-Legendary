namespace GooglePlayGames.BasicApi
{
	public enum LeaderboardStart
	{
		TopScores = 1,
		PlayerCentered
	}
}
