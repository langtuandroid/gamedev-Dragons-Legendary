namespace GooglePlayGames.BasicApi
{
	public enum LeaderboardCollection
	{
		Public = 1,
		Social
	}
}
