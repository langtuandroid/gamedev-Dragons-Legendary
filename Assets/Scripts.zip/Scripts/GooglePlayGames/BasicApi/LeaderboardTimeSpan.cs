namespace GooglePlayGames.BasicApi
{
	public enum LeaderboardTimeSpan
	{
		Daily = 1,
		Weekly,
		AllTime
	}
}
