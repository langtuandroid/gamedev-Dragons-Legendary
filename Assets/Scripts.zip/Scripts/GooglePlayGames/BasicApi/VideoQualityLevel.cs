namespace GooglePlayGames.BasicApi
{
	public enum VideoQualityLevel
	{
		Unknown = -1,
		SD,
		HD,
		XHD,
		FullHD
	}
}
