namespace GooglePlayGames.BasicApi.Events
{
	public enum EventVisibility
	{
		Hidden = 1,
		Revealed
	}
}
