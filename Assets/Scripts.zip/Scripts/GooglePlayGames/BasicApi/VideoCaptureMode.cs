namespace GooglePlayGames.BasicApi
{
	public enum VideoCaptureMode
	{
		Unknown = -1,
		File,
		Stream
	}
}
