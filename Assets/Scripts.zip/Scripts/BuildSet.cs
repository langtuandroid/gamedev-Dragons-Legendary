public class BuildSet
{
	public static PlatformType CurrentPlatformType;

	public static readonly string AppVer = "213";

	private const string SERVER_URL_DEV = "http://dev3.cookapps.com/mw_match/api.php";

	private const string SERVER_URL_REAL = "https://matchhero.cookappsgames.com/mw_match/api.php";

	public static readonly string serverURL = "https://matchhero.cookappsgames.com/mw_match/api.php";

	public static readonly bool isDEV;
}
