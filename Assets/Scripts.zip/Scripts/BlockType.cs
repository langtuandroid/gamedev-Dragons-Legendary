public enum BlockType
{
	None = -1,
	Blue,
	Green,
	Purple,
	Red,
	Yellow,
	White
}
