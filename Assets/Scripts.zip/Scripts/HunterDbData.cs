public class HunterDbData
{
	public int hunterIdx;

	public string hunterName;

	public int color;

	public int hunterTribe;

	public int maxTier;

	public int skillIdx;

	public bool openSpec;

	public string hunterClass;

	public string hunterImg1;

	public string hunterImg2;

	public string hunterImg3;

	public string hunterImg4;

	public string hunterImg5;

	public int hunterSize;
}
