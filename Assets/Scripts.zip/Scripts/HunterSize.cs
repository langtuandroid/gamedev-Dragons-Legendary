public enum HunterSize
{
	SMALL = 1,
	NORMAL,
	BIG
}
