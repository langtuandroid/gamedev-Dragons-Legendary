public class ARENA_USER_DATA
{
	public int arenaLevel;

	public int arenaTicket;

	public int arenaPoint;

	public string alarmYn;
}
