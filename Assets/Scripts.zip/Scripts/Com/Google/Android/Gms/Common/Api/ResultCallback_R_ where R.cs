namespace Com.Google.Android.Gms.Common.Api
{
	public interface ResultCallback<R> where R : Result
	{
		void onResult(R arg_Result_1);
	}
}
