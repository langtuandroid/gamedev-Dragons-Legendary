namespace Com.Google.Android.Gms.Common.Api
{
	public interface Result
	{
		Status getStatus();
	}
}
