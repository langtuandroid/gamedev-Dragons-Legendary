public class GAME_END_RESULT
{
	public int rewardStar;

	public int rewardExp;

	public int rewardCoin;

	public REWARDITEM[] rewardFixItem;

	public REWARDITEM[] rewardMonsterItem;
}
