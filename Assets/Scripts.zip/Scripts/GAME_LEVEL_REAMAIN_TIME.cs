public class GAME_LEVEL_REAMAIN_TIME
{
	public string success;

	public int errorCode;

	public GAME_LEVEL_REAMAIN_TIME_RESULT result;

	public CHECK_VERSION_RESULT[] force_update;
}
