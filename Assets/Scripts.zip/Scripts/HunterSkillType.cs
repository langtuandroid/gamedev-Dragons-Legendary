public enum HunterSkillType
{
	ATTACK = 1,
	RECOVERY,
	STUN,
	BLOCKCHANGE
}
