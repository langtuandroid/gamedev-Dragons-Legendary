public enum InGameResultReason
{
	Success,
	Enegy,
	Quit
}
