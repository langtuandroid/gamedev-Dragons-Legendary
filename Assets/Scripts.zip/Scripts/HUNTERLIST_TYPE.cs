public enum HUNTERLIST_TYPE
{
	NORMAL = 1,
	ARENA
}
