using UnityEngine;

public class Hunter_Base : MonoBehaviour
{
}
