public class ARENA_LEVEL_INFO
{
	public int puzzleR;

	public int puzzleY;

	public int puzzleG;

	public int puzzleB;

	public int puzzleP;

	public int puzzleH;
}
