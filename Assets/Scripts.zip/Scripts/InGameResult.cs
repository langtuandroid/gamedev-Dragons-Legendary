public enum InGameResult
{
	Success = 1,
	Fail = 0
}
