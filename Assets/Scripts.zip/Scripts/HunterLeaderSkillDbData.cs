public class HunterLeaderSkillDbData
{
	public int leaderSkillIdx;

	public string leaderSkillName;

	public int leaderskillType;

	public int leaderskillRequirement;

	public string leaderSkillDecreaseStat;

	public int leaderSkillDecreaseValue;

	public string leaderSkillIncreaseStat;

	public int leaderSkillIncreaseValue;

	public string leaderSkillDescription;
}
