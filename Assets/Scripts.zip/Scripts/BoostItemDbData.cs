public class BoostItemDbData
{
	public int boosterIdx;

	public string boosterName;

	public int boosterType;

	public int costType;

	public int costCount;

	public string boosterExplain;
}
