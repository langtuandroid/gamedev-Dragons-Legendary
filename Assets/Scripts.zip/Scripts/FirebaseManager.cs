using Firebase;
using System.Threading.Tasks;
using UnityEngine;

public class FirebaseManager : MonoBehaviour
{
	private void Start()
	{
		FirebaseApp.CheckAndFixDependenciesAsync().ContinueWith(delegate(Task<DependencyStatus> task)
		{
			DependencyStatus result = task.Result;
			if (result == DependencyStatus.Available)
			{
				MWLog.Log("Firebase Available !!!!");
			}
			else
			{
				UnityEngine.Debug.LogError($"Could not resolve all Firebase dependencies: {result}");
			}
		});
	}
}
