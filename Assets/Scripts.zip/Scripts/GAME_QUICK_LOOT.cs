public class GAME_QUICK_LOOT
{
	public string success;

	public int errorCode;

	public GAME_QUICK_LOOT_RESULT result;

	public CHECK_VERSION_RESULT[] force_update;
}
