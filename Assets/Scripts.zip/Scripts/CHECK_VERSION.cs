public class CHECK_VERSION
{
	public string success;

	public int errorCode;

	public CHECK_VERSION_RESULT result;
}
