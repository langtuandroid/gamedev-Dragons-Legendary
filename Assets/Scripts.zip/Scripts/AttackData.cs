public class AttackData
{
	public int damage;

	public int idx;
}
