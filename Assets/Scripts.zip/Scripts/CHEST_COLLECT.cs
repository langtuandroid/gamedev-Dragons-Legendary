public class CHEST_COLLECT
{
	public string success;

	public int errorCode;

	public CHEST_COLLECT_RESULT result;

	public CHECK_VERSION_RESULT[] force_update;
}
