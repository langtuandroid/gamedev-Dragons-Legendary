public class HunterPromotionDbData
{
	public int hunterColor;

	public int hunterMaxTier;

	public int hunterTier;

	public int hnip1;

	public int hnip1_N;

	public int hnip2;

	public int hnip2_N;

	public int hnip3;

	public int hnip3_N;

	public int hnip4;

	public int hnip4_N;

	public int needCoin;

	public int getExp;
}
