public class CHECK_AUTH
{
	public string success;

	public int errorCode;

	public CHECK_AUTH_RESULT result;
}
