namespace BlendModeShader2D
{
	public enum ColorSoloMode
	{
		None,
		Red,
		Green,
		Blue
	}
}
