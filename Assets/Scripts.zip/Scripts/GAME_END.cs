public class GAME_END
{
	public string success;

	public int errorCode;

	public GAME_END_RESULT result;

	public CHECK_VERSION_RESULT[] force_update;
}
