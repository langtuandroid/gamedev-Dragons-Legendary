public class CHECK_AUTH_RESULT
{
	public string exist;

	public int caUid;

	public string verifyId;
}
