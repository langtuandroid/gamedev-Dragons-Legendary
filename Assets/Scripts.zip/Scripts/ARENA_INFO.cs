public class ARENA_INFO
{
	public int arenaNo;

	public int year;

	public int week;

	public int color;

	public int color_buff;

	public int tribe;

	public int tribe_buff;

	public int endTimestamp;

	public int nextOpenTimestamp;

	public string endDateTime;

	public string nextOpenDateTime;

	public int endRemainTime;

	public int nextOpenRemainTime;
}
