public class CHEST_COLLECT_RESULT
{
	public ChestListDbData[] rewardList;
}
