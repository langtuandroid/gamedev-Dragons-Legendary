public class CHECK_VERSION_RESULT
{
	public int seq;

	public string device;

	public int version;

	public int force_update;

	public string title;

	public string message;

	public string link;
}
