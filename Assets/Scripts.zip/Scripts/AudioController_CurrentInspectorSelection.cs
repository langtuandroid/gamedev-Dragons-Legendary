using System;

[Serializable]
public class AudioController_CurrentInspectorSelection
{
	public int currentCategoryIndex;

	public int currentItemIndex;

	public int currentSubitemIndex;

	public int currentPlaylistEntryIndex;

	public int currentPlaylistIndex;
}
