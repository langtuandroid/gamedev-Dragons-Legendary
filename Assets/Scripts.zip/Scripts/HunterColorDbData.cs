public class HunterColorDbData
{
	public int color;

	public string colorName;

	public string colorOccupation;
}
