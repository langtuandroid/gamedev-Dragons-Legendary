public class ARENA_STORE_LIST_RESULT
{
	public ARENA_STORE_INFO[] arenaStoreInfo;
}
