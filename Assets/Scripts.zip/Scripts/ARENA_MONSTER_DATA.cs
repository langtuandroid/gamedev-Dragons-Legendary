public class ARENA_MONSTER_DATA
{
	public int uiImage;

	public int count;
}
