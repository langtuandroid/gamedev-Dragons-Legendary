public class ARENA_GAME_START_RESULT
{
	public int gameKey;

	public ARENA_LEVEL_INFO arena_level_info;

	public WaveDbData[] spec_arena_wave;

	public MonsterStatDbData[][] spec_monster_stat;
}
