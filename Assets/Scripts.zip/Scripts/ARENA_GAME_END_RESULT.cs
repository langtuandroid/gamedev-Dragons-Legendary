public class ARENA_GAME_END_RESULT
{
	public int rewardArenaPoint;

	public int rewardExp;

	public ChestListDbData[] rewardList;

	public int chestType;
}
