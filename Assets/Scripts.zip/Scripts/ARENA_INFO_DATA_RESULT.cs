public class ARENA_INFO_DATA_RESULT
{
	public ARENA_INFO arenaInfo;

	public ARENA_LEVEL_DATA[] arenaLevelList;

	public ARENA_USER_DATA userArenaInfo;

	public int[] lastWaveMonsterList;

	public ARENA_MONSTER_DATA[] monsterList;

	public ARENA_REWARD_INFO rewardInfo;

	public UserHunterData[] userHunterList;

	public ARENA_LEVEL_DATA activeLevelData;
}
