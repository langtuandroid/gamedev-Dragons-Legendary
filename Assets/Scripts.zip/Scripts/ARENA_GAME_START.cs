public class ARENA_GAME_START
{
	public string success;

	public int errorCode;

	public ARENA_GAME_START_RESULT result;

	public CHECK_VERSION_RESULT[] force_update;
}
