public enum AudioChannelType
{
	Default,
	Music,
	Ambience
}
