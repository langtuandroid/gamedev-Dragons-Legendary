public class HunterSkillDbData
{
	public int skillIdx;

	public string skillName;

	public string skillDescription;

	public int skillType;

	public int range;

	public int statType;

	public float multiple;

	public int times;

	public float recPowers;

	public int skillGauge;

	public int beforeBlock;

	public int afterBlock;

	public int motionType;
}
