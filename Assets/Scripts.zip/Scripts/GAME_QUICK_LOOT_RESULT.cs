public class GAME_QUICK_LOOT_RESULT
{
	public int rewardExp;

	public int rewardCoin;

	public int rewardChestKey;

	public REWARDITEM[] rewardFixItem;

	public REWARDITEM[] rewardMonsterItem;

	public ChestListDbData[] rewardChest;
}
