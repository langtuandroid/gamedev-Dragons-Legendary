public class HunterLevelDbData
{
	public int hunterIdx;

	public int hunterTier;

	public int hunterLevel;

	public int hnil;

	public int hnil_N;

	public int needCoin;

	public int hunterLeaderSkill;

	public int hunterIncHp;

	public int hunterHp;

	public int hunterIncAttack;

	public int hunterAttack;

	public int hunterIncRecovery;

	public int hunterRecovery;
}
