public enum InGameType
{
	Stage,
	Arena
}
