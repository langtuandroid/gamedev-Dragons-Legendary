public class ChestListDbData_Dummy
{
	public int chestIdx;

	public int chestHunter;

	public int hunterTier;

	public int hunterLevel;

	public int chestItem;

	public int chestItemN;

	public int probability;

	public int itemRarity;
}
