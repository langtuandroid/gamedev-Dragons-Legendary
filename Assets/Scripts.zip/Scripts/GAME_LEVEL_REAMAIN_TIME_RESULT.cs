public class GAME_LEVEL_REAMAIN_TIME_RESULT
{
	public int levelRemainTime;
}
