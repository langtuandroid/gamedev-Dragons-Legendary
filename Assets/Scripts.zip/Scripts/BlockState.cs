public enum BlockState
{
	Empty,
	Idle,
	Move,
	Select,
	MatchWait,
	MatchReady,
	MatchEnd,
	Hint
}
