public class ChapterDbData
{
	public int stage;

	public int chapter;

	public string chapterName;

	public int ocStar;

	public int rewardType;

	public int rewardCount;

	public int storeIdx;
}
