public class ARENA_LEVEL_DATA
{
	public int levelIdx;

	public int costTicket;

	public string chestName;

	public int chestType;

	public int booster1;

	public int booster2;

	public int booster3;

	public string passYn;
}
