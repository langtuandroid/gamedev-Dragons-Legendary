public enum HUNTER_STATE
{
	IDLE,
	ATTACK
}
