public class ChestDbData
{
	public int chestIdx;

	public string chestName;

	public int needItem;

	public int needItemNx1;

	public int needItemNx5;

	public int coolTimes;

	public int pickTimes;
}
