public enum HUNTER_MOTION
{
	SHORT = 1,
	LONG
}
