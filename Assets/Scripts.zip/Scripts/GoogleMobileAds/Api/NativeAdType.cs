namespace GoogleMobileAds.Api
{
	public enum NativeAdType
	{
		CustomTemplate
	}
}
