namespace GoogleMobileAds.Api
{
	public enum AdPosition
	{
		Top,
		Bottom,
		TopLeft,
		TopRight,
		BottomLeft,
		BottomRight,
		Center
	}
}
