using System;

namespace GoogleMobileAds.Api
{
	public class AdFailedToLoadEventArgs : EventArgs
	{
		public string Message
		{
			get;
			set;
		}
	}
}
