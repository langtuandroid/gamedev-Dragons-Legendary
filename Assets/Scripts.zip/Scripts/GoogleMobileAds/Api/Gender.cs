namespace GoogleMobileAds.Api
{
	public enum Gender
	{
		Unknown,
		Male,
		Female
	}
}
