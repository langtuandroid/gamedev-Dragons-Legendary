using GoogleMobileAds.Common.Mediation.AppLovin;
using UnityEngine;

namespace GoogleMobileAds.Android.Mediation.AppLovin
{
	public class AppLovinClient : IAppLovinClient
	{
		private static AppLovinClient instance = new AppLovinClient();

		public static AppLovinClient Instance => instance;

		private AppLovinClient()
		{
		}

		public void Initialize()
		{
			MonoBehaviour.print("AppLovin intialize received");
			AndroidJavaClass androidJavaClass = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
			AndroidJavaObject @static = androidJavaClass.GetStatic<AndroidJavaObject>("currentActivity");
			AndroidJavaClass androidJavaClass2 = new AndroidJavaClass("com.applovin.sdk.AppLovinSdk");
			androidJavaClass2.CallStatic("initializeSdk", @static);
		}

		public void SetHasUserConsent(bool hasUserConsent)
		{
			AndroidJavaClass androidJavaClass = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
			AndroidJavaObject @static = androidJavaClass.GetStatic<AndroidJavaObject>("currentActivity");
			AndroidJavaClass androidJavaClass2 = new AndroidJavaClass("com.applovin.sdk.AppLovinPrivacySettings");
			string str = (!hasUserConsent) ? "false" : "true";
			MonoBehaviour.print("Calling 'AppLovinPrivacySettings.setHasUserConsent()' with argument: " + str);
			androidJavaClass2.CallStatic("setHasUserConsent", hasUserConsent, @static);
		}

		public void SetIsAgeRestrictedUser(bool isAgeRestrictedUser)
		{
			AndroidJavaClass androidJavaClass = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
			AndroidJavaObject @static = androidJavaClass.GetStatic<AndroidJavaObject>("currentActivity");
			AndroidJavaClass androidJavaClass2 = new AndroidJavaClass("com.applovin.sdk.AppLovinPrivacySettings");
			string str = (!isAgeRestrictedUser) ? "false" : "true";
			MonoBehaviour.print("Calling 'AppLovinPrivacySettings.setIsAgeRestrictedUser()' with argument: " + str);
			androidJavaClass2.CallStatic("setIsAgeRestrictedUser", isAgeRestrictedUser, @static);
		}
	}
}
