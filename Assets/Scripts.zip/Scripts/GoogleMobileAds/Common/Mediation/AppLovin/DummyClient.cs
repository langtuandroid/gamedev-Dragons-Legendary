using System.Reflection;
using UnityEngine;

namespace GoogleMobileAds.Common.Mediation.AppLovin
{
	public class DummyClient : IAppLovinClient
	{
		public DummyClient()
		{
			UnityEngine.Debug.Log("Dummy " + MethodBase.GetCurrentMethod().Name);
		}

		public void Initialize()
		{
			UnityEngine.Debug.Log("Dummy " + MethodBase.GetCurrentMethod().Name);
		}

		public void SetHasUserConsent(bool hasUserConsent)
		{
			UnityEngine.Debug.Log("Dummy " + MethodBase.GetCurrentMethod().Name);
		}

		public void SetIsAgeRestrictedUser(bool isAgeRestrictedUser)
		{
			UnityEngine.Debug.Log("Dummy " + MethodBase.GetCurrentMethod().Name);
		}
	}
}
