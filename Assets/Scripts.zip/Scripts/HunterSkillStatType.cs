public enum HunterSkillStatType
{
	HP = 1,
	ATTACK,
	RECOVERY
}
