public class GAME_START_RESULT
{
	public int gameKey;

	public UserInfoData userInfo;
}
