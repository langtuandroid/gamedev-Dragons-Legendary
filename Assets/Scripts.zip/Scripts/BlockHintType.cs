public enum BlockHintType
{
	None = -2,
	Switch,
	Top,
	Top_Right,
	Right,
	Bottom_Right,
	Bottom,
	Bottom_Left,
	Left,
	Top_Left
}
