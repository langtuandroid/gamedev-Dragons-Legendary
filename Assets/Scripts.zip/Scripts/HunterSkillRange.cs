public enum HunterSkillRange
{
	ELSE,
	SINGLE,
	ALL
}
