public class CHECK_SUCCESS
{
	public string success;

	public int errorCode;

	public CHECK_VERSION_RESULT[] force_update;
}
