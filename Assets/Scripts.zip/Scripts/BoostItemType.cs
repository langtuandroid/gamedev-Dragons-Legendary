public enum BoostItemType
{
	SkillFullCharge = 1,
	CreateSpecialBlock,
	InfinityHintBlock,
	MatchTimePlus
}
