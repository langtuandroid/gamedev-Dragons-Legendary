public enum FloorStateType
{
	None,
	Open,
	Close
}
