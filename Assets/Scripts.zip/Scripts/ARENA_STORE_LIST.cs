public class ARENA_STORE_LIST
{
	public string success;

	public int errorCode;

	public ARENA_STORE_LIST_RESULT result;

	public CHECK_VERSION_RESULT[] force_update;
}
