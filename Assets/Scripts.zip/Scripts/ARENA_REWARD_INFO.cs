public class ARENA_REWARD_INFO
{
	public string rewardYn;

	public int preArenaLevel;

	public int preArenaPoint;

	public int arenaLevel;

	public int arenaPoint;

	public int nextArenaLevel;

	public int nextArenaPoint;
}
