public enum HUNTER_TRIBE
{
	TANKER = 1,
	MELEE,
	RANGED,
	MAGICIAN,
	HEALER
}
