namespace BlendModes
{
	public enum MaskBehaviour
	{
		Cutout,
		Normal
	}
}
