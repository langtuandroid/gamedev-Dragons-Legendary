namespace BlendModes
{
	public enum RenderMode
	{
		Grab,
		UnifiedGrab,
		Framebuffer,
		Overlay
	}
}
