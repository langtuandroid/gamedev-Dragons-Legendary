namespace BlendModes
{
	public enum ObjectType
	{
		Unknown,
		UIDefault,
		UIDefaultFont,
		SpriteDefault,
		MeshDefault,
		ParticleDefault,
		ScreenOverlay
	}
}
