namespace BlendModes
{
	public enum MaskMode
	{
		Disabled,
		NothingButMask,
		EverythingButMask
	}
}
