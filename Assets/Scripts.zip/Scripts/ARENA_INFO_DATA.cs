public class ARENA_INFO_DATA
{
	public string success;

	public int errorCode;

	public ARENA_INFO_DATA_RESULT result;

	public CHECK_VERSION_RESULT[] force_update;
}
