public class HunterInfo
{
	public HunterDbData Hunter;

	public HunterLevelDbData Stat;

	public HunterSkillDbData Skill;

	public int leaderSkillAttack;

	public int leaderSkillHp;

	public int leaderSkillRecovery;
}
